// Load environment variables
require('dotenv').config();

const { chromium } = require('playwright');
const path = require('path');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const fs = require('fs');
const config = require('./config');

const username = process.argv[2] || 'TestOstr';
const password = process.argv[3] || 'Abcd123#';
const gameurl = process.argv[4] || 'https://www.orionstrike777.com/admin/login';
const storageFile = path.join(__dirname, '../auth-state.json');

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(config.GEMINI_API_KEY);

async function solveCaptchaWithGemini(captchaImagePath) {
  try {
    console.log('Sending captcha image to Gemini Flash 2.0...');
    
    // Use Gemini Flash 2.0 model
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" });
    
    // Read the image file
    const imageBytes = fs.readFileSync(captchaImagePath);
    
    // Create the prompt for captcha solving
    const prompt = "The image is a captcha and will contain only numbers. Please read the text in this captcha image. Return ONLY the characters you see, with no additional explanation or formatting. Do not confuse similar-looking characters (for example, 7 is the digit seven, not the symbol >). If you cannot read it clearly, return 'ERROR'.";
    
    // Generate content with image
    const result = await model.generateContent([prompt, {
      inlineData: {
        data: imageBytes.toString('base64'),
        mimeType: "image/png"
      }
    }]);
    
    const response = await result.response;
    const captchaText = response.text().trim();
    
    console.log(`Gemini response: ${captchaText}`);
    
    if (captchaText === 'ERROR' || captchaText.length === 0) {
      throw new Error('Could not read captcha text from Gemini response');
    }
    
    // Clean up the screenshot file
    try {
      if (fs.existsSync(captchaImagePath)) {
        fs.unlinkSync(captchaImagePath);
        console.log('Captcha screenshot cleaned up');
      }
    } catch (cleanupError) {
      console.log('Warning: Could not clean up captcha screenshot:', cleanupError.message);
    }
    
    return captchaText;
  } catch (error) {
    console.error('Error solving captcha with Gemini:', error);
    
    // Clean up the screenshot file even on error
    try {
      if (fs.existsSync(captchaImagePath)) {
        fs.unlinkSync(captchaImagePath);
        console.log('Captcha screenshot cleaned up after error');
      }
    } catch (cleanupError) {
      console.log('Warning: Could not clean up captcha screenshot:', cleanupError.message);
    }
    
    throw error;
  }
}

async function findAndSolveCaptcha(page) {
  console.log('Looking for captcha elements...');
  
  // Captcha input field selectors
  const captchaInputSelectors = [
    'div.el-input.loginCode input.el-input__inner', // For sites with .el-input.loginCode wrapper
    'input.el-input__inner[placeholder="Please enter the verification code"]', // Most specific
    'input.el-input__inner', // Element UI
    'input.layui-input[name="captcha"]', // LayUI
    'input#txtVerifyCode', // ID-based
    'input[name="captcha"]', // Name-based
    'input[placeholder="Please enter the verification code"]',
    'input[placeholder="Captcha"]',
    'input[placeholder="Code"]',
    // Fallbacks/generics:
    'input[name*="captcha" i]',
    'input[id*="captcha" i]',
    'input[placeholder*="captcha" i]',
    'input[placeholder*="code" i]',
    'input[placeholder*="verification" i]',
    'input[placeholder*="verify" i]'
  ];
  
  // Visual captcha element selectors
  const captchaImageSelectors = [
    'img.imgCode', // GameVault captcha image
    'canvas',
    'img[src*="captcha" i]',
    'div[class*="captcha" i]',
    'span[class*="captcha" i]',
    'img[alt*="captcha" i]',
    'img[title*="captcha" i]'
  ];
  
  // Find captcha input field
  let captchaInput = null;
  for (const selector of captchaInputSelectors) {
    const element = await page.locator(selector).first();
    if (await element.isVisible()) {
      captchaInput = element;
      console.log(`Found captcha input field: ${selector}`);
      break;
    }
  }
  
  if (!captchaInput) {
    console.log('No captcha input field found, skipping captcha step.');
    return false;
  }
  
  // Find captcha image/element to screenshot
  let captchaElement = null;
  for (const selector of captchaImageSelectors) {
    const element = await page.locator(selector).first();
    if (await element.isVisible()) {
      captchaElement = element;
      console.log(`Found captcha element: ${selector}`);
      break;
    }
  }
  
  if (!captchaElement) {
    console.log('No captcha image element found, trying to screenshot the entire page...');
    // If no specific captcha element found, try to screenshot the area around the input
    const captchaInputBox = await captchaInput.boundingBox();
    if (captchaInputBox) {
      // Screenshot a larger area around the input field
      const screenshotPath = path.join(__dirname, config.CAPTCHA_SCREENSHOT_PATH);
      await page.screenshot({
        path: screenshotPath,
        clip: {
          x: Math.max(0, captchaInputBox.x - 200),
          y: Math.max(0, captchaInputBox.y - 100),
          width: captchaInputBox.width + 400,
          height: captchaInputBox.height + 200
        }
      });
      console.log(`Screenshot saved to: ${screenshotPath}`);
      
      // Solve captcha
      const captchaText = await solveCaptchaWithGemini(screenshotPath);
      
      // Fill the captcha input
      await captchaInput.fill(captchaText);
      console.log(`Captcha text filled: ${captchaText}`);
      
      return true;
    }
  } else {
    // Screenshot the specific captcha element
    const screenshotPath = path.join(__dirname, config.CAPTCHA_SCREENSHOT_PATH);
    await captchaElement.screenshot({ path: screenshotPath });
    console.log(`Captcha screenshot saved to: ${screenshotPath}`);
    
    // Solve captcha
    const captchaText = await solveCaptchaWithGemini(screenshotPath);
    
    // Fill the captcha input
    await captchaInput.fill(captchaText);
    console.log(`Captcha text filled: ${captchaText}`);
    
    return true;
  }
  
  return false;
}

async function loginAndSaveState() {
  // Launch browser in non-headless mode so you can see it
  const browser = await chromium.launch({
    headless: config.BROWSER_HEADLESS,
    slowMo: config.BROWSER_SLOW_MO // Add a small delay between actions for better visibility
  });
 
  // Create a new browser context
  const context = await browser.newContext();
 
  // Create a new page
  const page = await context.newPage();
 
  try {
    console.log('Opening login page...');
   
    // Navigate to the login page
    await page.goto(gameurl);
   
    console.log('Login page opened successfully!');
   
    // Wait for the page to load completely
    await page.waitForLoadState('networkidle');
   
    console.log('Filling in login credentials...');
   
    // Find and fill username field by placeholder (try username first, then account)
    let usernameInput = await page.locator('input[placeholder*="username" i]').first();
    if (await usernameInput.isVisible()) {
      await usernameInput.fill(username);
      console.log(`Username filled in username field: ${username}`);
    } else {
      // If username not found, try account field
      usernameInput = await page.locator('input[placeholder*="account" i]').first();
      if (await usernameInput.isVisible()) {
        await usernameInput.fill(username);
        console.log(`Username filled in account field: ${username}`);
      } else {
        console.log('Neither username nor account input field found');
      }
    }
    
    // Find and fill password field by placeholder
    const passwordInput = await page.locator('input[placeholder*="password" i]').first();
    if (await passwordInput.isVisible()) {
      await passwordInput.fill(password);
      console.log(`Password filled: ${password}`);
    } else {
      console.log('Password input field not found');
    }
   
    // Check the "remember password" checkbox (try multiple selectors)
    try {
      // Try different checkbox selectors
      const checkboxSelectors = [
        'span.el-checkbox__inner',
        'input[id="remember"]',
        'input[name="remember"]',
        'span.vs-checkbox',
        'span.vs-checkbox--check',
        'input[type="checkbox"]'
      ];
      
      let checkboxClicked = false;
      for (const selector of checkboxSelectors) {
        const checkbox = await page.locator(selector).first();
        if (await checkbox.isVisible()) {
          // Check if it's already checked (for input elements)
          if (selector.includes('input')) {
            const isChecked = await checkbox.isChecked();
            if (isChecked) {
              checkboxClicked = true;
              break;
            }
          }
          
          // Check if it's already checked (for custom checkboxes with CSS classes)
          if (selector.includes('span.el-checkbox__inner') || selector.includes('span.vs-checkbox')) {
            const parentLabel = await checkbox.locator('xpath=ancestor::label').first();
            if (await parentLabel.isVisible()) {
              const hasCheckedClass = await parentLabel.getAttribute('class');
              if (hasCheckedClass && hasCheckedClass.includes('is-checked')) {
                checkboxClicked = true;
                break;
              }
            }
          }
          
          // Click if not checked
          await checkbox.click();
          checkboxClicked = true;
          break;
        }
      }
      
      if (!checkboxClicked) {
        console.log('Remember password checkbox not found, skipping...');
      }
    } catch (error) {
      console.log('Error clicking remember password checkbox, skipping...');
    }
   
    console.log('Login form filled successfully!');
    
    // Check if captcha is present
    const captchaFound = await findAndSolveCaptcha(page);
    
    if (captchaFound) {
      console.log('Captcha found and solved automatically!');
    }
    
    console.log('Attempting to click login button...');
    
    // Try to find and click login button
    const loginButtonSelectors = [
      // Specific button selectors
      'button.el-button.el-button--primary span:has-text("Sign in")',
      'button.el-button.el-button--primary',
      'input[name="btnLogin"]',
      'input[id="btnLogin"]',
      'button.layui-btn.layui-block',
      'button.btn.btn-primary.login-btn',
      'button[type="submit"]',
      'input[type="submit"]',
      
      // Generic patterns
      'button:has-text("Sign in")',
      'button:has-text("Login")',
      'button:has-text("Log in")',
      'input[value*="Login" i]',
      'input[value*="Sign In" i]',
      'button[class*="login" i]',
      'button[class*="signin" i]',
      'a[class*="login" i]',
      'a[class*="signin" i]'
    ];
    
    let loginButtonClicked = false;
    for (const selector of loginButtonSelectors) {
      const loginButton = await page.locator(selector).first();
      if (await loginButton.isVisible()) {
        await loginButton.click();
        console.log(`Login button clicked using selector: ${selector}`);
        loginButtonClicked = true;
        break;
      }
    }
    
    if (!loginButtonClicked) {
      console.log('Login button not found automatically. Please click the login button manually.');
    }
    
    console.log('Waiting for login to complete...');
    
    // Wait for login to complete by checking when password field is no longer visible
    try {
      // Wait for the password field to disappear (indicating successful login)
      await page.waitForFunction(() => {
        const passwordInputs = document.querySelectorAll('input[placeholder*="password" i], input[type="password"]');
        return passwordInputs.length === 0 || Array.from(passwordInputs).every(input => !input.offsetParent);
      }, { timeout: config.LOGIN_TIMEOUT });
      
      console.log('Password field no longer visible - login appears successful!');
      
      // Additional wait to ensure dashboard is fully loaded
      await page.waitForTimeout(2000);
      
      // Save the authentication state
      await context.storageState({ path: storageFile });
      console.log(`Authentication state saved to: ${storageFile}`);
      
      // Also save credentials for future use
      const credentialsFile = path.join(__dirname, 'stored-credentials.json');
      const credentials = { username, password };
      fs.writeFileSync(credentialsFile, JSON.stringify(credentials, null, 2));
      console.log(`Credentials saved to: ${credentialsFile}`);
      console.log('You can now run account creation without logging in again!');
      
      // Close the browser after successful login and state saving
      await browser.close();
      console.log('Browser closed successfully.');
      
    } catch (error) {
      console.log('Login may not have been successful. Dashboard elements not found.');
      await browser.close();
      process.exit(1); // Exit with error code
    }
   
  } catch (error) {
    console.error('Error during login:', error);
    await browser.close();
  }
}

// Run the function
loginAndSaveState().catch(console.error);
